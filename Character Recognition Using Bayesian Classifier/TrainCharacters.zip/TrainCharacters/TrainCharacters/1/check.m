
cov=[1 2 3;4 5 6; 78 9 6]
coviii=cov;
for i=1:3
    for j=1:3
        if i~= j;       
            coviii(i,j)=0;
        end
    end
end