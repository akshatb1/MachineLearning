clc;
clear all;
%Read Input Training Images from data set
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TrainCharacters\TrainCharacters\1');
D = dir('*.jpg');
imcell = cell(1,numel(D));                              % cell to read and store images from a folder
imcellnew=cell(1,numel(D));                             % cell to store images after resizing and converting into double
for i = 1:numel(D)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell{i} = imread(D(i).name);
  I=imresize(imcell{i},0.25);                           % Resizing to 32*32
  J=im2double(I);                                       % Converting into Double
  imcellnew{i}=J;                                       % Storing in a new cell
end
clear imcell;
clear  I,J;

for i=1:numel(D)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector{i} = reshape((imcellnew{i})',1 ,32*32)';
end
clear imcellnew;

average= zeros(32*32, 1);                                   % Sum of all image column vector initialized as 0
for i=1:numel(D)
   average=average+ image_column_vector{i};
end

mu=average/200;
clear average;
                                       % Finding out mu using Maximum Likelihood = SUM(Xi)/No. of Samples
temp_cov = zeros(32*32,32*32);
for i=1:numel(D)
    temp_cov = temp_cov +(image_column_vector{i}-mu)*(transpose(image_column_vector{i}-mu));
end
cov = (1/200)*temp_cov;
clear temp_cov;
%------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------;
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TrainCharacters\TrainCharacters\2');
D2 = dir('*.jpg');
imcell2 = cell(1,numel(D2));                              % cell to read and store images from a folder
imcellnew2=cell(1,numel(D2));                             % cell to store images after resizing and converting into double
for i = 1:numel(D2)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell2{i} = imread(D2(i).name);
  I2=imresize(imcell2{i},0.25);                           % Resizing to 32*32
  J2=im2double(I2);                                       % Converting into Double
  imcellnew2{i}=J2;                                       % Storing in a new cell
end
clear imcell2;
clear I2,J2;
for i=1:numel(D2)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector2{i} = reshape((imcellnew2{i})',1 ,32*32)';
end
clear imcellnew2;

average2= zeros(32*32, 1);                                % Sum of all image column vector initialized as 0
for i=1:numel(D2)
   average2=average2+ image_column_vector2{i};
end

mu2=average2/200;    % Finding out mu using Maximum Likelihood = SUM(Xi)/No. of Samples

clear average2;
temp_cov2 = zeros(32*32,32*32);
for i=1:numel(D2)
    temp_cov2 = temp_cov2 +(image_column_vector2{i}-mu2)*(transpose(image_column_vector2{i}-mu2));
end
cov2 = (1/200)*temp_cov2;
clear temp_cov2;
%----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------;
%Read Input Training Images from data set
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TrainCharacters\TrainCharacters\3');
D3 = dir('*.jpg');
imcell3 = cell(1,numel(D3));                              % cell to read and store images from a folder
imcellnew3=cell(1,numel(D3));                             % cell to store images after resizing and converting into double
for i = 1:numel(D3)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell3{i} = imread(D3(i).name);
  I3=imresize(imcell3{i},0.25);                           % Resizing to 32*32
  J3=im2double(I3);                                       % Converting into Double
  imcellnew3{i}=J3;                                       % Storing in a new cell
end

for i=1:numel(D3)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector3{i} = reshape((imcellnew3{i})',1 ,32*32)';
end
clear imcell3;
clear I3,J3;
clear imcellnew3;
average3= zeros(32*32, 1);                                   % Sum of all image column vector initialized as 0
for i=1:numel(D)
   average3=average3+ image_column_vector3{i};
end

mu3=average3/200;                                             % Finding out mu using Maximum Likelihood = SUM(Xi)/No. of Samples
clear average3;

temp_cov3 = zeros(32*32,32*32);
for i=1:numel(D3)
    temp_cov3 = temp_cov3 +(image_column_vector3{i}-mu3)*(transpose(image_column_vector3{i}-mu3));
end
cov3 = (1/200)*temp_cov3;
clear temp_cov3;


%----------------------------------------------------------------------------------------------------------------------------------------------
%Loading Test Images
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TestCharacters\TestCharacters\TestCharacters\1');
D_test_e = dir('*.jpg');
imcell_test_e    = cell(1,numel(D_test_e));                              % cell to read and store images from a folder
imcellnew_test_e = cell(1,numel(D_test_e));
for i = 1:numel(D_test_e)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell_test_e{i} = imread(D_test_e(i).name);
  I_test_e=imresize(imcell_test_e{i},0.25);              % Resizing to 32*32
  J_test_e=im2double(I_test_e);                            % Converting into Double
  imcellnew_test_e{i}=J_test_e;                                       % Storing in a new cell
end

for i=1:numel(D_test_e)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector_test_e{i} = reshape((imcellnew_test_e{i})',1 ,32*32)';
end
clear imcell_test_e, imcellnew_test_e;

%Loading 'c'test images
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TestCharacters\TestCharacters\TestCharacters\2');
D_test_c = dir('*.jpg');
imcell_test_c    = cell(1,numel(D_test_c));                              % cell to read and store images from a folder
imcellnew_test_c = cell(1,numel(D_test_c));
for i = 1:numel(D_test_c)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell_test_c{i} = imread(D_test_c(i).name);
  I_test_c=imresize(imcell_test_c{i},0.25);              % Resizing to 32*32
  J_test_c=im2double(I_test_c);                            % Converting into Double
  imcellnew_test_c{i}=J_test_c;                                       % Storing in a new cell
end
image_column_vector_test_c=cell(1,numel(D_test_c));
for i=1:numel(D_test_c)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector_test_c{i} = reshape((imcellnew_test_c{i})',1 ,32*32)';
end
clear imcell_test_c,imcellnew_test_c;

%Loading 'i' test images
cd('D:\IITG Stuff\Acads\6th Sem\EE657 Pattern Recognition and Machine Learning\Assignments\ASSIGNMENT_1_PRML_2014\ASSIGNMENT_1_PRML_2014\TestCharacters\TestCharacters\TestCharacters\3');
D_test_eye = dir('*.jpg');
imcell_test_eye    = cell(1,numel(D_test_eye));                              % cell to read and store images from a folder
imcellnew_test_eye = cell(1,numel(D_test_eye));
for i = 1:numel(D_test_eye)                                      % Loop to read images, resize them to 32*32 and convert into double data type
  imcell_test_eye{i} = imread(D_test_eye(i).name);
  I_test_eye=imresize(imcell_test_eye{i},0.25);              % Resizing to 32*32
  J_test_eye=im2double(I_test_eye);                            % Converting into Double
  imcellnew_test_eye{i}=J_test_eye;                                       % Storing in a new cell
end

for i=1:numel(D_test_eye)                                        % To create Column Vectors from Each Image Matrix
  image_column_vector_test_eye{i} = reshape((imcellnew_test_eye{i})',1 ,32*32)';
end
clear imcell_test_eye, imcellnew_test_eye;
%-------------------------------------------------------------------------------------------------------------------------------------------------------------------
%Part1(a) (i) The samples of a given character class are modelled by a separate covariance matrix
cov;
cov2;
cov3;
mu;
mu2;
mu3;
%Classifying 'e' characters
% for i=1:numel(D_test_e)
%     G1 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov+eye(32*32,32*32)))*mu))*image_column_vector_test_e{i} - 0.5*(transpose(mu)*((inv(cov + eye(32*32,32*32))))*mu) -0.5*(log(det(cov + eye(32*32,32*32))));
%     G2 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov2 + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov2+eye(32*32,32*32)))*mu2))*image_column_vector_test_e{i} - 0.5*(transpose(mu2)*((inv(cov2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov2 + eye(32*32,32*32))));
%     G3 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov3 + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov3+eye(32*32,32*32)))*mu3))*image_column_vector_test_e{i} - 0.5*(transpose(mu3)*((inv(cov3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov3 + eye(32*32,32*32))));
%     if ( ((G1-G2) >0 ) & ((G1-G3) > 0) )
%         i
%         disp('image belong to category e (actual category = e) ');
%     end
%      if ( ((G1-G2) <0 ) &((G2-G3)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%     end
%      if ( ((G1-G3) <0 ) &((G2-G3) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%     end
% end
%Classifying 'c' characters
% correct_c_count=0;
% wrong_c_count= 0;
% for i=1:numel(D_test_c)
%     G1_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov+eye(32*32,32*32)))*mu))*image_column_vector_test_c{i} - 0.5*(transpose(mu)*((inv(cov + eye(32*32,32*32))))*mu) -0.5*(log(det(cov + eye(32*32,32*32))));
%     G2_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov2 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov2+eye(32*32,32*32)))*mu2))*image_column_vector_test_c{i} - 0.5*(transpose(mu2)*((inv(cov2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov2 + eye(32*32,32*32))));
%     G3_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov3 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov3+eye(32*32,32*32)))*mu3))*image_column_vector_test_c{i} - 0.5*(transpose(mu3)*((inv(cov3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov3 + eye(32*32,32*32))));
%     if ( ((G1_c-G2_c) >0 ) & ((G1_c-G3_c) > 0) )
%         i
%         disp('image belong to category e (actual category = c) ');
%         wrong_c_count=wrong_c_count+1;
%     end
%      if ( ((G1_c-G2_c) <0 ) &((G2_c-G3_c)> 0) )
%         i
%         disp(' th image belong to category c (actual category = c)');
%         correct_c_count=correct_c_count+1;
%     end
%     if ( ((G1_c-G3_c) <0 ) &((G2_c-G3_c) <0) )
%         i
%         disp(' th image belong to category i(actual category = c) ');
%         wrong_c_count=wrong_c_count+1;
%     end
% end
% correct_c_count
% wrong_c_count

% Classifying_i_character:
% a=0;
% b=0;
% c=0;
% for i=1:numel(D_test_eye)
%     G1_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov +  eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov+eye(32*32,32*32)))*mu))*image_column_vector_test_eye{i} - 0.5*(transpose(mu)*((inv(cov + eye(32*32,32*32))))*mu) -0.5*(log(det(cov + eye(32*32,32*32))));
%     G2_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov2 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov2+eye(32*32,32*32)))*mu2))*image_column_vector_test_eye{i} - 0.5*(transpose(mu2)*((inv(cov2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov2 + eye(32*32,32*32))));
%     G3_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov3 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov3+eye(32*32,32*32)))*mu3))*image_column_vector_test_eye{i} - 0.5*(transpose(mu3)*((inv(cov3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov3 + eye(32*32,32*32))));
%     if ( ((G1_1-G2_1) >0 ) & ((G1_1-G3_1) > 0) )
%         i
%         disp('image belong to category e (actual category = i) ');
%         a=a+1;
%     end
%     if ( ((G1_1-G2_1) <0 ) &((G2_1-G3_1)> 0) )
%         i
%         disp(' th image belong to category c (actual category = i)');
%         b=b+1;
%     end
%     if ( ((G3_1 - G1_1) >0 ) &((G3_1-G2_1) >0) )
%         i
%         disp(' th image belong to category i(actual category = i) ');
%         c=c+1
%     end
% end
% %----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
%(ii)The samples across all the character classes are pooled together to generate a common non diagonal covariance matrix .
common_cov= (cov+ cov2+cov3)/3;
a1=0;
a2=0;
a3=0;
% for i=1:numel(D_test_e)
%     H1_e= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_e{i}-0.5*(transpose(mu)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu;
%     H2_e= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_e{i}-0.5*(transpose(mu2)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu2;
%     H3_e= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_e{i}-0.5*(transpose(mu3)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((H1_e-H2_e) >0 ) & ((H1_e-H3_e) > 0) )
%         i
%         disp('image belong to category e (actual category = e) ');
%         a1=a1+1;
%     end
%      if ( ((H1_e-H2_e) <0 ) &((H2_e-H3_e)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%         a2=a2+1;
%     end
%      if ( ((H1_e-H3_e) <0 ) &((H2_e-H3_e) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%         a3=a3+1;
%     end
% end
% for i=1:numel(D_test_c)
%     H1_c= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_c{i}-0.5*(transpose(mu)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu;
%     H2_c= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_c{i}-0.5*(transpose(mu2)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu2;
%     H3_c= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_c{i}-0.5*(transpose(mu3)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((H1_c-H2_c) >0 ) & ((H1_c-H3_c) > 0) )
%          i
%          disp('image belong to category e (actual category = c) ');
%          a1=a1+1;
%     end
%     
%      if ( ((H1_c-H2_c) <0 ) &((H2_c-H3_c)> 0) )
%         i
%         disp(' th image belong to category c (actual category = c)');
%         a2=a2+1;
%     end
%       if ( ((H1_c-H3_c) <0 ) &((H2_c-H3_c) <0) )
%         i
%         disp(' th image belong to category i(actual category = c) ');
%         a3=a3+1;
%     end
% end
% ii_correct_eye_count=0;
% ii_wrong_eye_count  =0;

% for i=1:numel(D_test_eye)
%     H1_eye= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_eye{i}-0.5*(transpose(mu)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu;
%     H2_eye= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_eye{i}-0.5*(transpose(mu2)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu2;
%     H3_eye= (transpose(inv(common_cov + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_eye{i}-0.5*(transpose(mu3)*(inv(common_cov + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((H1_eye-H3_eye) <0 ) &((H2_eye-H3_eye) <0) )
%         i
%         disp(' th image belong to category i(actual category = i) ');
%         a1=a1+1;
%     end
%     if ( ((H1_eye-H2_eye) >0 ) & ((H1_eye-H3_eye) > 0) )
%         i
%         disp('image belong to category e (actual category = i) ');
%         
%         a2=a2+1;
%     end
%     
%     if ( ((H1_eye-H2_eye) <0 ) &((H2_eye-H3_eye)> 0) )
%         i
%         disp(' th image belong to category c (actual category = i)');
%         a3=a3+1;
%     end
%     
% end


    
    

%-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 %Part1(a) :iii :The samples of a given character class are separately modelled by a diagonal covariance matrix sigma. The diagonal entries of the matrix correspond to the variances of
% the individual features. The features are assumed to be independent- hence their  cross variances are forced to zero.

coviii=cov;
for i=1:1024
    for j=1:1024
        if i~= j;       
            coviii(i,j)=0;
        end
    end
end
coviii2=cov2;
for i=1:1024
    for j=1:1024
        if i~= j;       
            coviii2(i,j)=0;
        end
    end
end
coviii3=cov3;
for i=1:1024
    for j=1:1024
        if i~= j;       
            coviii3(i,j)=0;
        end
    end
end
% k_count1=0;
% k_count2=0;
% k_count3=0;
% for i=1:numel(D_test_e)
%     K1 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(coviii + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(coviii+eye(32*32,32*32)))*mu))*image_column_vector_test_e{i} - 0.5*(transpose(mu)*((inv(coviii + eye(32*32,32*32))))*mu) -0.5*(log(det(coviii + eye(32*32,32*32))));
%     K2 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(coviii2 + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(coviii2+eye(32*32,32*32)))*mu2))*image_column_vector_test_e{i} - 0.5*(transpose(mu2)*((inv(coviii2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(coviii2 + eye(32*32,32*32))));
%     K3 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(coviii3 + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(coviii3+eye(32*32,32*32)))*mu3))*image_column_vector_test_e{i} - 0.5*(transpose(mu3)*((inv(coviii3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(coviii3 + eye(32*32,32*32))));
%     if ( ((K1-K2) >0 ) & ((K1-K3) > 0) )
%         i
%         disp('image belong to category e (actual category = e) ');
%         k_count1=k_count1+1;
%     end
%     if ( ((K1-K2) <0 ) &((K2-K3)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%         k_count2=k_count2+1;
%     end
%     if ( ((K1-K3) <0 ) &((K2-K3) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%         k_count3=k_count3+1;
%     end
% end
% %Classifying 'c' characters
% k_count4=0;
% k_count5=0;
% k_count6=0;
% for i=1:numel(D_test_c)
%     K1_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(coviii + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(coviii+eye(32*32,32*32)))*mu))*image_column_vector_test_c{i} - 0.5*(transpose(mu)*((inv(coviii + eye(32*32,32*32))))*mu) -0.5*(log(det(coviii + eye(32*32,32*32))));
%     K2_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(coviii2 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(coviii2+eye(32*32,32*32)))*mu2))*image_column_vector_test_c{i} - 0.5*(transpose(mu2)*((inv(coviii2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(coviii2 + eye(32*32,32*32))));
%     K3_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(coviii3 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(coviii3+eye(32*32,32*32)))*mu3))*image_column_vector_test_c{i} - 0.5*(transpose(mu3)*((inv(coviii3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(coviii3 + eye(32*32,32*32))));
%     if ( ((K1_c-K2_c) >0 ) & ((K1_c-K3_c) > 0) )
%         i
%         disp('image belong to category e (actual category = c) ');
%         k_count4=k_count4+1;
%     end
%      if ( ((K1_c-K2_c) <0 ) &((K2_c-K3_c)> 0) )
%         i
%         disp(' th image belong to category c (actual category = c)');
%         k_count5=k_count5+1;
%     end
%     if ( ((K1_c-K3_c) <0 ) &((K2_c-K3_c) <0) )
%         i
%         disp(' th image belong to category i(actual category = c) ');
%         k_count6=k_count6+1;
% %     end
% % end
% 
% % 
% % Classifying_i_character:
% k_count7=0;
% k_count8=0;
% k_count9=0;
% for i=1:numel(D_test_eye)
%     K1_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(coviii +  eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(coviii+eye(32*32,32*32)))*mu))*image_column_vector_test_eye{i} - 0.5*(transpose(mu)*((inv(coviii + eye(32*32,32*32))))*mu) -0.5*(log(det(coviii + eye(32*32,32*32))));
%     K2_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(coviii2 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(coviii2+eye(32*32,32*32)))*mu2))*image_column_vector_test_eye{i} - 0.5*(transpose(mu2)*((inv(coviii2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(coviii2 + eye(32*32,32*32))));
%     K3_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(coviii3 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(coviii3+eye(32*32,32*32)))*mu3))*image_column_vector_test_eye{i} - 0.5*(transpose(mu3)*((inv(coviii3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(coviii3 + eye(32*32,32*32))));
%     if ( ((K1_1-K2_1) >0 ) & ((K1_1-K3_1) > 0) )
%         i
%         disp('image belong to category e (actual category = i) ');
%         a=a+1;
%         k_count7=k_count7+1;
%     end
%     if ( ((K1_1-K2_1) <0 ) &((K2_1-K3_1)> 0) )
%         i
%         disp(' th image belong to category c (actual category = i)');
%         k_count8=k_count8+1;
%     end
%     if ( ((K3_1 - K1_1) >0 ) &((K3_1-K2_1) >0) )
%         i
%         disp(' th image belong to category i(actual category = i) ');
%         k_count9=k_count9+1;
%     end
% end
% --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
% (iv)The samples across all the character classes are pooled to generate a common diagonal covariance matrix  The diagonal entries correspond to the variances of the
% individual features, that are considered to be independent.
% cov_fourth=(coviii+ coviii2 +coviii3) /3;
% 
% correct_e =0;
% wrong_e= 0;
% for i=1:numel(D_test_e)
%     J1_e= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_e{i}-0.5*(transpose(mu)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu;
%     J2_e= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_e{i}-0.5*(transpose(mu2)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu2;
%     J3_e= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_e{i}-0.5*(transpose(mu3)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((J1_e-J2_e) >0 ) & ((J1_e-J3_e) > 0) )
%         i
%         disp('image belong to category e (actual category = e) ');
%         correct_e=correct_e+1;
%     end
%     if ( ((J1_e-J2_e) <0 ) &((J2_e-J3_e)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%         wrong_e=wrong_e+1;
%     end
%     if ( ((J1_e-J3_e) <0 ) &((J2_e-J3_e) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%         wrong_e=wrong_e+1;
%     end
% end
% correct_e
% wrong_e
% correct_c=0;
% wrong_c=0;
% for i=1:numel(D_test_c)
%     J1_c= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_c{i}-0.5*(transpose(mu)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu;
%     J2_c= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_c{i}-0.5*(transpose(mu2)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu2;
%     J3_c= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_c{i}-0.5*(transpose(mu3)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((J1_c-J2_c) >0 ) & ((J1_c-J3_c) > 0) )
%         i
%         disp('image belong to category e (actual category = c) ');
%         wrong_c=wrong_c+1;
%     end
%    
%     if ( ((J1_c-J2_c) <0 ) &((J2_c-J3_c)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%         correct_c=correct_c+1;
%     end
%     if ( ((J1_c-J3_c) <0 ) &((J2_c-J3_c) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%         wrong_c=wrong_c+1;
%     end
% end
% % correct_c
% % wrong_c
% correct_i=0;
% wrong_i=0;
% for i=1:numel(D_test_eye)
%     J1_eye= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu))*image_column_vector_test_eye{i}-0.5*(transpose(mu)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu;
%     J2_eye= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu2))*image_column_vector_test_eye{i}-0.5*(transpose(mu2)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu2;
%     J3_eye= (transpose(inv(cov_fourth + 0.1*eye(32*32,32*32))*mu3))*image_column_vector_test_eye{i}-0.5*(transpose(mu3)*(inv(cov_fourth + 0.1*eye(32*32,32*32))))*mu3;
%     if ( ((J3_eye -J1_eye) >0 ) &((J3_eye -J2_eye) >0) )
%         i
%         disp(' th image belong to category i(actual category = i) ');
%         correct_i=correct_i+1;
%     end
%     if ( ((J1_eye-J2_eye) >0 ) & ((J1_eye-J3_eye) > 0) )
%         i
%         disp('image belong to category e (actual category = i) ');
%         wrong_i=wrong_i+1;
%     end
%     if ( ((J1_eye-J2_eye) <0 ) &((J2_eye-J3_eye)> 0) )
%         i
%         disp(' th image belong to category c (actual category = i)');
%         wrong_i=wrong_i+1;
%     end
%    
% end
% correct_i
% wrong_i
%--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
%(v)The covariance matrix of each class is forced to be spherical.
coviii;
coviii2;
coviii3;
temp_sigma=0;
temp_sigma2=0;
temp_sigma3=0;
for i=1:1024
    temp_sigma=temp_sigma+coviii(i,i);
end
cov_v = (1/1024)*temp_sigma*eye(1024,1024);

for i=1:1024
    temp_sigma2=temp_sigma2+coviii2(i,i);
end
cov_v2=(1/1024)*temp_sigma2*eye(1024,1024);

for i=1:1024
    temp_sigma3=temp_sigma3+coviii3(i,i);
end
cov_v3=(1/1024)*temp_sigma3*eye(1024,1024);
%Classifying 'e' characters
l_count1=0;
l_count2=0;
l_count3=0;
% for i=1:numel(D_test_e)
%     L1 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov_v + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov_v+eye(32*32,32*32)))*mu))*image_column_vector_test_e{i} - 0.5*(transpose(mu)*((inv(cov_v + eye(32*32,32*32))))*mu) -0.5*(log(det(cov_v + eye(32*32,32*32))));
%     L2 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov_v2+ eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov_v2+eye(32*32,32*32)))*mu2))*image_column_vector_test_e{i} - 0.5*(transpose(mu2)*((inv(cov_v2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov_v2 + eye(32*32,32*32))));
%     L3 =(transpose(image_column_vector_test_e{i}))*(-0.5*(inv(cov_v3 + eye(32*32,32*32))))*(image_column_vector_test_e{i}) + (transpose((inv(cov_v3+eye(32*32,32*32)))*mu3))*image_column_vector_test_e{i} - 0.5*(transpose(mu3)*((inv(cov_v3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov_v3 + eye(32*32,32*32))));
%     if ( ((L1-L2) >0 ) & ((L1-L3) > 0) )
%         i
%         disp('image belong to category e (actual category = e) ');
%         l_count1=l_count1+1;
%     end
%      if ( ((L1-L2) <0 ) &((L2-L3)> 0) )
%         i
%         disp(' th image belong to category c (actual category = e)');
%         l_count2=l_count2+1;
%     end
%      if ( ((L1-L3) <0 ) &((L2-L3) <0) )
%         i
%         disp(' th image belong to category i(actual category = e) ');
%         l_count3=l_count3+1;
%     end
% end
%Classifying 'c' characters
l_count4=0;
l_count5=0;
l_count6=0;
for i=1:numel(D_test_c)
    L1_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov_v + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov_v+eye(32*32,32*32)))*mu))*image_column_vector_test_c{i} - 0.5*(transpose(mu)*((inv(cov_v + eye(32*32,32*32))))*mu) -0.5*(log(det(cov_v + eye(32*32,32*32))));
    L2_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov_v2 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov_v2+eye(32*32,32*32)))*mu2))*image_column_vector_test_c{i} - 0.5*(transpose(mu2)*((inv(cov_v2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov_v2 + eye(32*32,32*32))));
    L3_c =(transpose(image_column_vector_test_c{i}))*(-0.5*(inv(cov_v3 + eye(32*32,32*32))))*(image_column_vector_test_c{i}) + (transpose((inv(cov_v3+eye(32*32,32*32)))*mu3))*image_column_vector_test_c{i} - 0.5*(transpose(mu3)*((inv(cov_v3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov_v3 + eye(32*32,32*32))));
    if ( ((L1_c-L2_c) >0 ) & ((L1_c-L3_c) > 0) )
        i
        disp('image belong to category e (actual category = c) ');
       
        l_count4=l_count4+1;
    end
     if ( ((L1_c-L2_c) <0 ) &((L2_c-L3_c)> 0) )
        i
        disp(' th image belong to category c (actual category = c)');
        
        l_count5=l_count5+1;
    end
    if ( ((L1_c-L3_c) <0 ) &((L2_c-L3_c) <0) )
        i
        disp(' th image belong to category i(actual category = c) ');
        l_count6=l_count6+1;
    end
end


%classifying 'i' character
l_count7=0;
l_count8=0;
l_count9=0;
for i=1:numel(D_test_eye)
    L1_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov_v +  eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov_v+eye(32*32,32*32)))*mu))*image_column_vector_test_eye{i} - 0.5*(transpose(mu)*((inv(cov_v + eye(32*32,32*32))))*mu) -0.5*(log(det(cov_v + eye(32*32,32*32))));
    L2_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov_v2 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov_v2+eye(32*32,32*32)))*mu2))*image_column_vector_test_eye{i} - 0.5*(transpose(mu2)*((inv(cov_v2 + eye(32*32,32*32))))*mu2) -0.5*(log(det(cov_v2 + eye(32*32,32*32))));
    L3_1 =(transpose(image_column_vector_test_eye{i}))*(-0.5*(inv(cov_v3 + eye(32*32,32*32))))*(image_column_vector_test_eye{i}) + (transpose((inv(cov_v3+eye(32*32,32*32)))*mu3))*image_column_vector_test_eye{i} - 0.5*(transpose(mu3)*((inv(cov_v3 + eye(32*32,32*32))))*mu3) -0.5*(log(det(cov_v3 + eye(32*32,32*32))));
    if ( ((L1_1-L2_1) >0 ) & ((L1_1-L3_1) > 0) )
        i
        disp('image belong to category e (actual category = i) ');
        l_count7=l_count7+1;
    end
    if ( ((L1_1-L2_1) <0 ) &((L2_1-L3_1)> 0) )
        i
        disp(' th image belong to category c (actual category = i)');
         l_count8=l_count8+1;
    end
    if ( ((L3_1 - L1_1) >0 ) &((L3_1-L2_1) >0) )
        i
        disp(' th image belong to category i(actual category = i) ');
         l_count9=l_count9+1;
    end
end